class TrieNode:
    def __init__(self):
        self.char = None
        self.children = {}
        self.answer = []
        self.word = None
